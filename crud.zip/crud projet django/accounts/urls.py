from django.urls import path
from .views import SignUpView, CustomLoginView, CustomLogoutView, UserListView, UserUpdateView, UserDeleteView

urlpatterns = [
    # CRUD URLs
path('users/', UserListView.as_view(), name='user_list'),
path('users/<int:pk>/edit/', UserUpdateView.as_view(), name='user_edit'),
path('users/<int:pk>/delete/', UserDeleteView.as_view(), name='user_delete'),

    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', CustomLogoutView.as_view(), name='logout'),
    path('signup/', SignUpView.as_view(), name='signup'),

]
